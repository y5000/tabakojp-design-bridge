Synthetic connector upload test only. Not a design delivery.
